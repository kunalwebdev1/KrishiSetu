import '/flutter_flow/flutter_flow_util.dart';
import 'payment_sucessful_widget.dart' show PaymentSucessfulWidget;
import 'package:flutter/material.dart';

class PaymentSucessfulModel extends FlutterFlowModel<PaymentSucessfulWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
