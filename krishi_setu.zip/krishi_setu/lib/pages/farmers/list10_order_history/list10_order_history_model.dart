import '/flutter_flow/flutter_flow_util.dart';
import 'list10_order_history_widget.dart' show List10OrderHistoryWidget;
import 'package:flutter/material.dart';

class List10OrderHistoryModel
    extends FlutterFlowModel<List10OrderHistoryWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
