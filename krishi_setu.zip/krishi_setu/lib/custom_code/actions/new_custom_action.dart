// Automatic FlutterFlow imports
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom actions
import 'package:flutter/material.dart';
// Begin custom action code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'dart:io';
import 'package:image_picker/image_picker.dart';

Future<String?> newCustomAction() async {
  // Call the uploadImage function
  return await uploadImage();
}

Future<String?> uploadImage() async {
  final ImagePicker picker = ImagePicker();
  final XFile? pickedFile = await picker.getImage(source: ImageSource.gallery);

  if (pickedFile != null) {
    final File file = File(pickedFile.path);
    // TODO: Upload the file to your server or cloud storage
    return file.path;
  }

  return null;
}
