import '/flutter_flow/flutter_flow_util.dart';
import 'save_address_widget.dart' show SaveAddressWidget;
import 'package:flutter/material.dart';

class SaveAddressModel extends FlutterFlowModel<SaveAddressWidget> {
  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
