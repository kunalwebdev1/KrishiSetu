import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: const FirebaseOptions(
            apiKey: "AIzaSyBauKs4KLkLTawGcLcMl5MyiQ8udMZBRJc",
            authDomain: "krishi-setu-kburyg.firebaseapp.com",
            projectId: "krishi-setu-kburyg",
            storageBucket: "krishi-setu-kburyg.appspot.com",
            messagingSenderId: "1039217101037",
            appId: "1:1039217101037:web:477953624865eb6c9e64e4"));
  } else {
    await Firebase.initializeApp();
  }
}
